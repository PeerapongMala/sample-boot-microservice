INSERT INTO user (id, name, email)
VALUES (1, 'John Doe', 'johndoe@example.com');

INSERT INTO user (id, name, email)
VALUES (2, 'Jane Smith', 'janesmith@example.com');

INSERT INTO user (id, name, email)
VALUES (3, 'Mike Johnson', 'mikejohnson@example.com');

INSERT INTO user (id, name, email)
VALUES (4, 'Emily Brown', 'emilybrown@example.com');

INSERT INTO user (id, name, email)
VALUES (5, 'David Wilson', 'davidwilson@example.com');

INSERT INTO user (id, name, email)
VALUES (6, 'Sarah Taylor', 'sarahtaylor@example.com');

INSERT INTO user (id, name, email)
VALUES (7, 'Robert Anderson', 'robertanderson@example.com');

INSERT INTO User (id, name, email)
VALUES (8, 'Laura Davis', 'lauradavis@example.com');

INSERT INTO user (id, name, email)
VALUES (9, 'Michael Lee', 'michaellee@example.com');

INSERT INTO user (id, name, email)
VALUES (10, 'Jennifer Clark', 'jenniferclark@example.com');