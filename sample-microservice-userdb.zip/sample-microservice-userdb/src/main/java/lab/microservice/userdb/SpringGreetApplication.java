package lab.microservice.userdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringGreetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringGreetApplication.class, args);
	}

}
